Andrew Myers and Samuel Chu
andrewlmyers and samuelechu

How to use VisageLivre:
1)Type 'make'.
2)To manually add users, fill up network.txt.
  a)Format of network.txt is Username\nPassword\nFull Name\nOccupation\Wall Posts
  b)Wall Posts are Time\nContent of Post
  c)There are two \n in between users.
3)Run ./Launch to bring up the menu, and go from there.

Note: As of now, VisageLivre does not support multi-line Wall Posts. This will be fixed shortly.

Note: There are some test files included in this version of VisageLivre. These do not affect the functionality of the program, and are solely for testing purposes.
